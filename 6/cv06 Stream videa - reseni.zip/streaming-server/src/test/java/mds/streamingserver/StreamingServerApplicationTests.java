package mds.streamingserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreamingServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
