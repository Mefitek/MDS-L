package mds.uvod;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UvodApplicationTests {

	@Test
	void contextLoads() {
	}

}
