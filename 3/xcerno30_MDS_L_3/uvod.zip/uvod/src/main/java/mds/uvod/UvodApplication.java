package mds.uvod;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UvodApplication {

	public static void main(String[] args) {
		SpringApplication.run(UvodApplication.class, args);
	}

}
