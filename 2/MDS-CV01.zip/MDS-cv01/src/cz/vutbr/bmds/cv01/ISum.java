package cz.vutbr.bmds.cv01;

public interface ISum {

    // Každá třída, která implementuje toto rozhraní musí mít metodu sum();
    public int sum();

}